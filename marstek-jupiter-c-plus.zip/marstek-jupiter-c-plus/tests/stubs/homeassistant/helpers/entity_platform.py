AddEntitiesCallback = object
